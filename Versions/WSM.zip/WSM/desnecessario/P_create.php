<?php
$host = 'localhost';
$db = 'wsm';
$user = 'root';
$pass = '';

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $valor = $_POST['valor'];
    $categoria = $_POST['categoria'];
    $quantidade = $_POST['quantidade'];
    //$quantidadeatual = $_POST['quantidadeatual'];

    // Verificar se o campo nome foi preenchido
    if (empty($nome)) {
        echo "<script>alert('Falta preencher o nome'); window.history.back();</script>";
        exit();
    }

    // Inserir os dados no banco
    $stmt = $conn->prepare("INSERT INTO tbl_produto (PRO_Descricao, PRO_Valor, PRO_Categoria, PRO_Quantidade) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('sdsi', $nome, $valor, $categoria, $quantidade);

    if ($stmt->execute()) {
        echo "<script>alert('Cadastro concluído'); window.location.href = 'P_create.html';</script>";
    } else {
        echo "Erro ao cadastrar: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>