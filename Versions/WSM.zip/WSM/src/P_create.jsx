import { useState } from 'react';
import reactLogo from './assets/logo versao2_branca.png'
import './dashboard.css';
import { Link } from 'react-router-dom';

function PCreate() {
  const [formData, setFormData] = useState({
    nome: '',
    descricao: '',
    genero: '',
    animal: '',
    ong: '',
    foto: null,
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
    }));
  };

  const validaForm = (e) => {
    e.preventDefault();
    const { nome, foto } = formData;

    if (!nome) {
      alert('Falta preencher o nome');
      return;
    }

    if (foto) {
      const extensoesValidas = ['jpg', 'jpeg', 'png'];
      const extensao = foto.name.split('.').pop().toLowerCase();

      if (!extensoesValidas.includes(extensao)) {
        alert('A imagem não é jpg, jpeg ou png');
        return;
      }
    }

    alert('Cadastro concluído');
    // Aqui você pode enviar os dados para o backend futuramente
  };

  return (
    <>
      <div className="sidebar">
        <ul className="side-menu">
          <li className="active"><Link to="/P_create"><i className="bx bxs-dog"></i>Create</Link></li>
          <li><a href="#"><i className="bx bxs-user-detail"></i>Update</a></li>
          <li><a href="#"><i className="bx bx-x-circle"></i>Delete</a></li>
          <li><a href="#"><i className="bx bx-receipt"></i>List</a></li>
          <li><a href="#"><i className="bx bxs-file-find"></i>Adoc./Apad.</a></li>
          <li><a href="#"><i className="bx bx-group"></i>Usuários</a></li>
        </ul>
        <ul className="side-menu">
          <li>
            <a href="#" className="logout">
              <i className="bx bx-log-out-circle"></i>
              Logout
            </a>
          </li>
        </ul>
      </div>

        <div className="content">
          <nav>
             <img src={reactLogo} alt="logo" />
            <i className="bx bx-menu"></i>
            <form>
              <div className="form-input">
                <input type="search" placeholder="Pesquisar..." />
                <button className="search-btn" type="submit"><i className="bx bx-search"></i></button>
              </div>
            </form>
            <input type="checkbox" id="theme-toggle" hidden />
            <label htmlFor="theme-toggle" className="theme-toggle"></label>
            <a href="#" className="notif">
              <i className="bx bx-bell"></i>
              <span className="count">12</span>
            </a>
          </nav>

        <main>


          <div className="bottom-data">
            <div className="orders">
              <div className="chartt">
                <div className="box">
                  <fieldset>
                    <h2>Cadastro de Animais</h2>
                    <form onSubmit={validaForm}>
                      <label htmlFor="nome">Nome do Animal:</label><br />
                      <input type="text" id="nome" name="nome" required onChange={handleChange} /><br /><br />

                      <label htmlFor="descricao">Descrição:</label><br />
                      <textarea id="descricao" name="descricao" rows="4" required onChange={handleChange}></textarea><br /><br />

                      <label htmlFor="genero">Sexo:</label><br />
                      <select name="genero" id="generos" required onChange={handleChange}>
                        <option value="">Selecione...</option>
                        <option value="Femea">Fêmea</option>
                        <option value="Macho">Macho</option>
                      </select><br /><br />

                      <label htmlFor="ong">ONG em que o animal se encontra:</label><br />
                      <input type="text" id="ong" name="ong" required onChange={handleChange} /><br /><br />

                      <button type="submit">Cadastrar</button>
                    </form>
                  </fieldset>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export default PCreate;
