import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./App";
import PCreate from "./P_create";

function AppRoutes() {
  return (
    <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/App" element={<Home />} />
          <Route path="/P_create" element={<PCreate />} />
        </Routes>
    </Router>
  );
}

export default AppRoutes;