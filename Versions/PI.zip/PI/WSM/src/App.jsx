import { useState } from 'react';
import reactLogo from './assets/logo versao2_branca.png';
import viteLogo from '/vite.svg';
import './login.css';
import { Link } from "react-router-dom";

function App() {
  const [cpf, setCpf] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:3001/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cpf, senha })
      });

      const data = await res.json();

      if (res.ok) {
        setSucesso('Login bem-sucedido!');
        setErro('');
        // Aqui você pode redirecionar ou salvar token
      } else {
        setErro(data.error || 'Credenciais inválidas');
        setSucesso('');
      }
    } catch (err) {
      setErro('Erro de conexão com o servidor');
      setSucesso('');
    }
  };

  return (
    <div className="login-page">
      <div className="login-card-container">
        <div className="login-card">
          <div className="login-card-top">
            <div className="login-card-logo">
              <img src={reactLogo} alt="logo" />
            </div>
            <div className="login-card-subtitle">Web System Management</div>
          </div>

          <div className="login-card-header">
            <h1>Bem-vindo</h1>
            <div>Faça login para acessar o sistema</div>
          </div>

          <form className="login-card-form" onSubmit={handleLogin}>
            <div className="form-item">
              <span className="form-item-icon material-symbols-rounded">description</span>
              <input
                type="number"
                placeholder="Digite seu ID"
                name="cpf"
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                required
              />
            </div>

            <div className="form-item">
              <span className="form-item-icon material-symbols-rounded">lock</span>
              <input
                type="password"
                placeholder="Digite sua Senha"
                name="senha"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                required
              />
            </div>

            <div className="form-item-other">
              <div className="checkbox">
                <input type="checkbox" id="rememberMeCheckbox" defaultChecked />
                <label htmlFor="rememberMeCheckbox">Lembre-me</label>
              </div>
              <a href="#">Esqueci minha senha!</a>
            </div>

            {erro && <div className="erro">{erro}</div>}
            {sucesso && <div className="sucesso">{sucesso}</div>}

            <input className="button" type="submit" value="Login" />
          </form>

          <div className="login-card-footer">
            Não tem uma conta? <a href="cadastro.html">Solicitar acesso.</a>
            <Link to="/App">Login</Link>
            <Link to="/P_create">Cadastro de Produto</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
