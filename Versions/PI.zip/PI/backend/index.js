const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());

// Configuração do multer para upload de imagens
const upload = multer({ dest: 'uploads/' });

// Caminho para o banco de dados
const dbPath = path.resolve(__dirname, 'meubanco.db');
const db = new sqlite3.Database(dbPath, err => {
  if (err) console.error('Erro ao abrir banco:', err);
  else console.log('Banco conectado com sucesso');
});

// Rota para listar usuários
app.get('/usuarios', (req, res) => {
  db.all('SELECT * FROM usuarios', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Rota de login
app.post('/login', (req, res) => {
  const { cpf, senha } = req.body;

  db.get('SELECT * FROM usuarios WHERE cpf = ? AND senha = ?', [cpf, senha], (err, row) => {
    if (err) return res.status(500).json({ error: 'Erro no servidor' });
    if (!row) return res.status(401).json({ error: 'Credenciais inválidas' });

    res.json({ mensagem: 'Login bem-sucedido', usuario: row });
  });
});

// Rota de cadastro de animais
app.post('/animais', upload.single('foto'), (req, res) => {
  const { nome, descricao, genero, ong } = req.body;
  const foto = req.file ? req.file.filename : null;

  db.run(
    'INSERT INTO animais (nome, descricao, genero, ong, foto) VALUES (?, ?, ?, ?, ?)',
    [nome, descricao, genero, ong, foto],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, mensagem: 'Animal cadastrado com sucesso' });
    }
  );
});

app.listen(3001, () => console.log('🚀 Servidor rodando na porta 3001'));
