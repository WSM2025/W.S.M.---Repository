const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'meubanco.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cpf TEXT NOT NULL UNIQUE,
      senha TEXT NOT NULL
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS animais (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      descricao TEXT,
      genero TEXT,
      ong TEXT,
      foto TEXT
    )
  `);

  db.run(`INSERT INTO usuarios (cpf, senha) VALUES ('12345678900', 'senha123')`);
  db.run(`INSERT INTO animais (nome, descricao, genero, ong, foto) VALUES ('Bolt', 'Cão amigável', 'Macho', 'ONG Esperança', null)`);

  console.log('Banco criado com sucesso!');
});

db.close();
